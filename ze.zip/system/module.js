/*
𝗦𝗖𝗥𝗜𝗣𝗧 𝗠𝗗 𝗫 𝗖𝗥𝗔𝗦𝗛 𝗕𝗢𝗧
𝗖𝗥𝗘𝗗𝗜𝗧𝗦 : 𝗕𝗬 𝗫𝗛𝗜𝗥𝗢𝗢 𝗘𝗫𝗦𝗘𝗡𝗧𝗥𝗬
*/
module.exports = {
modul: {
	axios: require('axios'),
	boom: require('@hapi/boom'),
	baileys: require('@whiskeysockets/baileys'), 
	chalk: require('chalk'),
	cheerio: require('cheerio'),
	child_process: require('child_process'),
	fs: require('fs'),
	fetch: require('node-fetch'),
	FormData: require('form-data'),
	FileType: require('file-type'),
	process: require('process'),
	PhoneNumber: require('awesome-phonenumber')
}
}