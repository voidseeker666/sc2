/*
𝗦𝗖𝗥𝗜𝗣𝗧 𝗠𝗗 𝗫 𝗖𝗥𝗔𝗦𝗛 𝗕𝗢𝗧
𝗖𝗥𝗘𝗗𝗜𝗧𝗦 : 𝗕𝗬 𝗫𝗛𝗜𝗥𝗢𝗢 𝗘𝗫𝗦𝗘𝗡𝗧𝗥𝗬
*/
const { MessageType } = require('@whiskeysockets/baileys');
const fs = require('fs');

async function sendImage(ptz, from, imageData, caption, mm) {
    const buffer = Buffer.from(imageData.split(',')[1], 'base64');
    await ptz.sendMessage(from, buffer, MessageType.image, { caption: caption, quoted: m });
}

module.exports = { sendImage };
